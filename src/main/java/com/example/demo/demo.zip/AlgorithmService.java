// File Location: src/main/java/com/example/demo/AlgorithmService.java
package com.example.demo;

import org.springframework.stereotype.Service;

// Importing all necessary classes explicitly
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.Collections;
import java.util.AbstractMap;
import java.util.Arrays;

@Service
public class AlgorithmService {

    public AlgorithmResult runBfs(Map<String, List<Edge>> graph, String startNode) {
        List<VisualizationStep> steps = new ArrayList<>();
        Queue<String> queue = new LinkedList<>();
        Set<String> visited = new LinkedHashSet<>();

        if (graph.get(startNode) == null) {
            return new AlgorithmResult(steps, new AlgorithmSummary()); // Return empty for error
        }

        queue.add(startNode);
        visited.add(startNode);
        steps.add(createStep(null, new HashSet<>(visited), new ArrayList<>(queue), "Starting BFS at " + startNode));

        while (!queue.isEmpty()) {
            String currentNode = queue.poll();
            steps.add(createStep(currentNode, new HashSet<>(visited), new ArrayList<>(queue), "Processing " + currentNode));

            if (graph.get(currentNode) == null) continue;

            for (Edge edge : graph.get(currentNode)) {
                String neighbor = edge.getNode();
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);
                    steps.add(createStep(currentNode, new HashSet<>(visited), new ArrayList<>(queue), "Discovering " + neighbor));
                }
            }
        }
        
        AlgorithmSummary summary = new AlgorithmSummary();
        summary.setTitle("BFS Complete!");
        summary.setDetails("Traversal Order: " + String.join(" -> ", visited));
        summary.setVisitedCount(visited.size());
        summary.setAlgorithmName("Breadth-First Search (BFS)");

        return new AlgorithmResult(steps, summary);
    }

    public AlgorithmResult runDfs(Map<String, List<Edge>> graph, String startNode) {
        List<VisualizationStep> steps = new ArrayList<>();
        Stack<String> stack = new Stack<>();
        Set<String> visited = new LinkedHashSet<>();

        stack.push(startNode);
        
        while(!stack.isEmpty()){
            String currentNode = stack.pop();
            if(visited.contains(currentNode)) continue;

            visited.add(currentNode);
            VisualizationStep step = new VisualizationStep();
            step.currentNode = currentNode;
            step.visitedNodes = new HashSet<>(visited);
            step.queueOrStack = new ArrayList<>(stack);
            steps.add(step);
            
            if (graph.get(currentNode) == null) continue;
            List<Edge> neighbors = new ArrayList<>(graph.get(currentNode));
            Collections.reverse(neighbors);

            for(Edge edge : neighbors){
                if(!visited.contains(edge.getNode())){
                    stack.push(edge.getNode());
                }
            }
        }

        AlgorithmSummary summary = new AlgorithmSummary();
        summary.setTitle("DFS Complete!");
        summary.setDetails("Traversal Order: " + String.join(" -> ", visited));
        summary.setVisitedCount(visited.size());
        summary.setAlgorithmName("Depth-First Search (DFS)");

        return new AlgorithmResult(steps, summary);
    }
    
    public AlgorithmResult runDijkstra(Map<String, List<Edge>> graph, String startNode, String endNode) {
        List<VisualizationStep> steps = new ArrayList<>();
        Map<String, Integer> distances = new HashMap<>();
        Map<String, String> previousNodes = new HashMap<>();
        PriorityQueue<Map.Entry<String, Integer>> pq = new PriorityQueue<>(Map.Entry.comparingByValue());
        Set<String> visited = new HashSet<>();

        for (String node : graph.keySet()) {
            distances.put(node, Integer.MAX_VALUE);
        }
        distances.put(startNode, 0);
        pq.add(new AbstractMap.SimpleEntry<>(startNode, 0));

        while (!pq.isEmpty()) {
            String currentNode = pq.poll().getKey();
            if (visited.contains(currentNode)) continue;
            
            visited.add(currentNode);

            VisualizationStep step = new VisualizationStep();
            step.currentNode = currentNode;
            step.distances = new HashMap<>(distances);
            step.visitedNodes = new HashSet<>(visited);
            steps.add(step);

            if (currentNode.equals(endNode)) break;
            if (graph.get(currentNode) == null) continue;

            for (Edge edge : graph.get(currentNode)) {
                if (!visited.contains(edge.getNode())) {
                    int newDist = distances.get(currentNode) + edge.getWeight();
                    if (newDist < distances.get(edge.getNode())) {
                        distances.put(edge.getNode(), newDist);
                        previousNodes.put(edge.getNode(), currentNode);
                        pq.add(new AbstractMap.SimpleEntry<>(edge.getNode(), newDist));
                    }
                }
            }
        }

        AlgorithmSummary summary = new AlgorithmSummary();
        summary.setTitle("Dijkstra's Complete!");
        summary.setAlgorithmName("Dijkstra's Algorithm");

        Integer finalDistance = distances.get(endNode);
        if (finalDistance != null && finalDistance != Integer.MAX_VALUE) {
            List<String> path = new ArrayList<>();
            String at = endNode;
            while(at != null){
                path.add(at);
                at = previousNodes.get(at);
            }
            Collections.reverse(path);
            
            if (!steps.isEmpty()) {
                steps.get(steps.size() - 1).path = path;
            }

            summary.setDetails("Shortest Path: " + String.join(" -> ", path));
            summary.setPathLength(finalDistance);
        } else {
            summary.setDetails("No path found to the target node.");
            summary.setPathLength(Integer.MAX_VALUE);
        }
        
        return new AlgorithmResult(steps, summary);
    }

    public AlgorithmResult runMst(Map<String, List<Edge>> graph, String startNode) {
        List<VisualizationStep> steps = new ArrayList<>();
        Set<String> mstEdges = new HashSet<>();
        Map<String, Integer> minCost = new HashMap<>();
        Map<String, String> parent = new HashMap<>();
        PriorityQueue<Map.Entry<String, Integer>> pq = new PriorityQueue<>(Map.Entry.comparingByValue());
        Set<String> visited = new HashSet<>();
        int totalWeight = 0;

        for (String node : graph.keySet()) {
            minCost.put(node, Integer.MAX_VALUE);
        }
        minCost.put(startNode, 0);
        pq.add(new AbstractMap.SimpleEntry<>(startNode, 0));

        while (!pq.isEmpty() && visited.size() < graph.size()) {
            String currentNode = pq.poll().getKey();
            if (visited.contains(currentNode)) continue;

            visited.add(currentNode);
            if (parent.get(currentNode) != null) {
                mstEdges.add(parent.get(currentNode) + "-" + currentNode);
                mstEdges.add(currentNode + "-" + parent.get(currentNode));
                totalWeight += minCost.get(currentNode);
            }

            VisualizationStep step = new VisualizationStep();
            step.currentNode = currentNode;
            step.visitedNodes = new HashSet<>(visited);
            step.mstEdges = new HashSet<>(mstEdges);
            steps.add(step);

            if (graph.get(currentNode) == null) continue;
            for (Edge edge : graph.get(currentNode)) {
                if (!visited.contains(edge.getNode()) && edge.getWeight() < minCost.get(edge.getNode())) {
                    minCost.put(edge.getNode(), edge.getWeight());
                    parent.put(edge.getNode(), currentNode);
                    pq.add(new AbstractMap.SimpleEntry<>(edge.getNode(), edge.getWeight()));
                }
            }
        }
        
        AlgorithmSummary summary = new AlgorithmSummary();
        summary.setTitle("MST (Prim's) Complete!");
        summary.setDetails("Total Weight: " + totalWeight);
        summary.setTotalWeight(totalWeight);
        summary.setAlgorithmName("Minimum Spanning Tree (Prim's)");
        
        return new AlgorithmResult(steps, summary);
    }

    public AlgorithmResult runFloydWarshall(Map<String, List<Edge>> graph) {
        List<VisualizationStep> steps = new ArrayList<>();
        List<String> nodes = new ArrayList<>(graph.keySet());
        Collections.sort(nodes);
        int n = nodes.size();
        int[][] dist = new int[n][n];

        for (int i = 0; i < n; i++) {
            Arrays.fill(dist[i], 1_000_000);
            dist[i][i] = 0;
        }

        for (int i = 0; i < n; i++) {
            String nodeName = nodes.get(i);
            if(graph.get(nodeName) == null) continue;
            for (Edge edge : graph.get(nodeName)) {
                int j = nodes.indexOf(edge.getNode());
                if (j != -1) {
                    dist[i][j] = edge.getWeight();
                }
            }
        }
        
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (dist[i][k] != 1_000_000 && dist[k][j] != 1_000_000 && dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
            VisualizationStep step = new VisualizationStep();
            step.currentNode = nodes.get(k);
            step.distanceMatrix = cloneMatrix(dist);
            step.highlightI = k;
            steps.add(step);
        }
        
        AlgorithmSummary summary = new AlgorithmSummary();
        summary.setTitle("Floyd-Warshall Complete!");
        summary.setDetails("All-pairs shortest paths matrix has been calculated.");
        summary.setAlgorithmName("Floyd-Warshall Algorithm");

        return new AlgorithmResult(steps, summary);
    }
    
    private int[][] cloneMatrix(int[][] src) {
        if (src == null) return null;
        return Arrays.stream(src).map(int[]::clone).toArray(int[][]::new);
    }

    private VisualizationStep createStep(String currentNode, Set<String> visited, List<String> queue, String message) {
        VisualizationStep step = new VisualizationStep();
        step.currentNode = currentNode;
        step.visitedNodes = new HashSet<>(visited);
        step.queueOrStack = new ArrayList<>(queue);
        step.message = message;
        return step;
    }
}