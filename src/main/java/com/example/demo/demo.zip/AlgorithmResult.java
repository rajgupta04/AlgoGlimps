// File Location: src/main/java/com/example/demo/AlgorithmResult.java
package com.example.demo;

import java.util.List;

public class AlgorithmResult {
    private List<VisualizationStep> steps;
    private AlgorithmSummary summary;

    // Constructor
    public AlgorithmResult(List<VisualizationStep> steps, AlgorithmSummary summary) {
        this.steps = steps;
        this.summary = summary;
    }

    // Getters and Setters (essential for Spring to create the JSON)
    public List<VisualizationStep> getSteps() {
        return steps;
    }

    public void setSteps(List<VisualizationStep> steps) {
        this.steps = steps;
    }

    public AlgorithmSummary getSummary() {
        return summary;
    }

    public void setSummary(AlgorithmSummary summary) {
        this.summary = summary;
    }
}