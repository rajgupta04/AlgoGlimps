// File Location: src/main/java/com/example/demo/AlgorithmSummary.java
package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;

// This annotation tells Spring not to include fields that are null in the final JSON.
// This is great for keeping the response clean.
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AlgorithmSummary {

    private String title;
    private String details;
    private String algorithmName;
    private Integer pathLength;
    private Integer visitedCount;
    private Integer totalWeight;

    // --- Getters and Setters for all fields ---
    // Your IDE can generate these automatically.

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getAlgorithmName() {
        return algorithmName;
    }

    public void setAlgorithmName(String algorithmName) {
        this.algorithmName = algorithmName;
    }

    public Integer getPathLength() {
        return pathLength;
    }

    public void setPathLength(Integer pathLength) {
        this.pathLength = pathLength;
    }

    public Integer getVisitedCount() {
        return visitedCount;
    }

    public void setVisitedCount(Integer visitedCount) {
        this.visitedCount = visitedCount;
    }

    public Integer getTotalWeight() {
        return totalWeight;
    }

    public void setTotalWeight(Integer totalWeight) {
        this.totalWeight = totalWeight;
    }
}