// File Location: src/main/java/com/example/demo/AlgorithmController.java
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/algorithms")
@CrossOrigin(origins = "*") // Allows your HTML file to call this server
public class AlgorithmController {

    @Autowired
    private AlgorithmService algorithmService;

    @PostMapping("/bfs")
    public AlgorithmResult executeBfs(@RequestBody GraphData request) {
        return algorithmService.runBfs(request.getGraph(), request.getStartNode());
    }

    @PostMapping("/dfs")
    public AlgorithmResult executeDfs(@RequestBody GraphData request) {
        return algorithmService.runDfs(request.getGraph(), request.getStartNode());
    }
    
    @PostMapping("/dijkstra")
    public AlgorithmResult executeDijkstra(@RequestBody GraphData request) {
        return algorithmService.runDijkstra(request.getGraph(), request.getStartNode(), request.getTargetNode());
    }

    @PostMapping("/mst")
    public AlgorithmResult executeMst(@RequestBody GraphData request) {
        return algorithmService.runMst(request.getGraph(), request.getStartNode());
    }

    @PostMapping("/floyd-warshall")
    public AlgorithmResult executeFloydWarshall(@RequestBody GraphData request) {
        return algorithmService.runFloydWarshall(request.getGraph());
    }
}